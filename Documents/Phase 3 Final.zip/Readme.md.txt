1) Create Venv
2) install requirements.txt with "pip install -r requirements.txt"
3) type "voila" in cmd/terminal within root folder containing notebooks
4) Select and review whichever one you like